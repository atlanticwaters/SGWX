# SGWX Process Page — Animation Spec for Framer

## Overview
Single long-scroll page. Dark mode (Carbon #1a1d1c background). 
6 sections total: Opening → 4 Growth Stages → Closing.
Each stage locks into view, animates its content, then releases.

---

## Brand System (non-negotiable)

**Colors**
- Sage: #6EA87F (primary accent, stages 1 + 3)
- Steel Blue: #799BA9 (secondary accent, stages 2 + 4)
- Carbon Deep: #1a1d1c (page background)
- White Paper: #F9F9F9 (primary text)
- White 60%: rgba(249,249,249,0.6) (body text, descriptors)
- White 30%: rgba(249,249,249,0.3) (tertiary text, nav dots)
- White 12%: rgba(249,249,249,0.12) (borders, dividers)
- White 6%: rgba(249,249,249,0.06) (tag backgrounds, numeral strokes)

**Typography — Roboto only**
- Stage names: Thin (100) — this is the signature move
- Labels + CTAs: Medium (500), ALL CAPS, wide letter-spacing
- Body: Light (300)
- Service tags: Regular (400)
- Logo + Numerals: Black (900)

**Brand rules applied**
- "+" not "and" or "&" (e.g., "content + experiences")
- Outlined numerals with 2px stroke
- Sideways rotated text on left edge
- Weight variation creates hierarchy (thin vs black)

---

## Global Elements

### Progress Bar
- Fixed to top of viewport, 2px height
- Gradient: Sage → Steel Blue (left to right)
- Width scrubs from 0% to 100% across full page scroll
- z-index: 1000

### Stage Nav Dots
- Fixed right side, vertically centered
- 4 dots, 8px diameter, 1px border white-30
- Appear when first stage section enters viewport (top 80%)
- Disappear when closing section reaches top 50%
- Active dot: filled Sage, scale 1.3x
- Hover: label appears to the left ("launch", "engage", etc.)
- Click: smooth scroll to that section

---

## Section 1: Opening Frame

**Layout:** Full viewport height, centered content, no scroll

**Elements + initial state:**
| Element | Initial | Final | Duration | Delay |
|---------|---------|-------|----------|-------|
| SGWX logo (Black 900, 4.5rem) | opacity 0, scale 0.9 | opacity 1, scale 1 | 1.0s | 0.3s page load |
| "Smart Content + Experiences" (Sage, Light 300) | opacity 0 | opacity 1 | 0.8s | stagger after logo |
| Subtitle line (White 60%) | opacity 0 | opacity 1 | 0.8s | stagger |
| Scroll indicator | opacity 0 | opacity 1 | 0.6s | last |

**Ambient:** Radial gradient glow (Sage 30%, 600px, blur 80px) centered behind logo

**On scroll:** Entire opening fades to 0 + scales to 0.95 (scrubbed, top-to-80%)

---

## Section 2: Stage — Launch

**Scroll trigger:** Animation starts when section top hits 65% of viewport

**Animation sequence (all ease: power2.out):**

| Step | Element | Property | Duration | Overlap |
|------|---------|----------|----------|---------|
| 1 | Sideways label "stage 01 — launch" | opacity 0→1 | 0.6s | — |
| 2 | Outlined numeral "01" | opacity 0→1 | 1.0s | starts 0.4s before step 1 ends |
| 3 | Label "stage 01" | opacity 0→1, y 20→0 | 0.5s | overlapping |
| 4 | Name "launch" (Thin 100, ~4.5rem) | opacity 0→1, y 30→0 | 0.7s | overlapping |
| 5 | Focus text | opacity 0→1, y 20→0 | 0.6s | overlapping |
| 6 | Service tags (×6) | opacity 0→1, y 15→0 | 0.4s each, 0.08s stagger | overlapping |
| 7 | Proof point | opacity 0→1, y 20→0 | 0.6s | last |

**Numeral parallax:** "01" drifts y: 0 → -60px (scrubbed across full section scroll)

**Accent color:** Sage
**Ambient glow:** Sage, bottom-right, 500px, blur 120px, opacity 0.06

**Reverse:** All animations reverse when scrolling back up past trigger

**Services:** brand architecture, visual identity systems, positioning strategy, marketing roadmaps, messaging, MVPs

**Proof point:** EverPass Media — NFL Sunday Ticket® brand launch

---

## Section 3: Stage — Engage

**Identical animation structure to Launch** (same timing, same sequence)

**Accent color:** Steel Blue (label, proof marker, proof result, tag hover)
**Ambient glow:** Steel Blue, top-left

**Services:** campaigns, content, games, experiences, activations, engagement

**Proof point:** JULABO USA — One Degree Can Change Everything campaign

---

## Section 4: Stage — Mobilize

**Identical animation structure to Launch**

**Accent color:** Sage
**Ambient glow:** Sage, right-center

**Services:** community growth, membership + loyalty, ambassadors, influencers + KOLs, creator partnerships, amplification

**Proof point:** Dr. Squatch — Sydney Sweeney's Bathwater Bliss (sold out instantly, social trending)

---

## Section 5: Stage — Transform

**Identical animation structure to Launch**

**Accent color:** Steel Blue
**Ambient glow:** Steel Blue, bottom-left

**Services:** transformation strategy, organizational alignment, cross-cultural adoption, engagement initiatives, celebratory moments, generative AI + automation

**Proof point:** Mindstrong — Corporate Summit (91% satisfaction, 95% connection score)

---

## Section 6: Closing Frame

**Scroll trigger:** top of section hits 60% viewport

**Animation sequence:**

| Step | Element | Property | Duration | Stagger |
|------|---------|----------|----------|---------|
| 1 | 4 stage words ("launch engage mobilize transform") | opacity 0→1, y 20→0 | 0.5s | 0.15s between each |
| 2 | "SAGEWORX" wordmark (Black 900) | opacity 0→1, scale 0.9→1 | 0.8s | — |
| 3 | "Emerge. Engage. Evolve." | opacity 0→1 | 0.6s | — |
| 4 | CTA button | opacity 0→1, y 20→0 | 0.5s | — |

**Stage words color:** odd = Sage, even = Steel Blue
**CTA:** "ACTIVATE YOUR TEAM" — Sage background, Carbon Deep text, Medium 500

---

## Framer Implementation Notes

### What Framer can handle natively
- Opening appear animations (use "Appear" trigger with delays)
- Stage content fade + slide up (use "Scroll Into View" trigger)
- Progress bar (Code Override reading scroll position)
- Nav dot visibility toggle
- Closing sequence

### Where GSAP is needed (or strongly recommended)
- **Staggered service tags** — Framer can approximate with manual delays per element, but GSAP stagger is cleaner
- **Numeral parallax** — Framer's "While Scrolling" can do this, but GSAP scrub is smoother
- **Reverse on scroll back** — GSAP's toggleActions handle this automatically
- **Coordinated timelines** — the overlapping sequence per stage is one GSAP timeline, would be many individual Framer animations

### GSAP in Framer setup
1. Add to Framer site Settings → Custom Code → `<head>`:
```html
<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/gsap.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/ScrollTrigger.min.js"></script>
```
2. Use Code Overrides or a Code Component to run the animation JS
3. Target elements by class name (all class names in the CSS file are the selectors)

### Alternative: Framer-native approach
If the developer prefers no custom code, the page can be built using Framer's scroll animation tools with these approximations:
- Each element gets its own "Scroll Into View" trigger
- Manually offset delays to simulate the staggered timeline
- Use "While Scrolling In View" for the numeral parallax
- Accept that reverse-on-scroll-back won't be as smooth

---

## File Manifest

| File | Purpose |
|------|---------|
| `sgwx-process-scroll.html` | Complete working prototype (open in Chrome) |
| `sgwx-process-styles.css` | All styles separated, with design tokens as CSS variables |
| `sgwx-process-animations.js` | All GSAP logic separated, heavily commented |
| `sgwx-process-spec.md` | This document — animation spec in plain language |
