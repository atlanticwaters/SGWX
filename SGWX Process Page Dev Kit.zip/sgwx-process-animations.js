/* ═══════════════════════════════════════════════════════════════
   SGWX PROCESS PAGE — SCROLL-DRIVEN ANIMATIONS
   GSAP ScrollTrigger Logic for Framer Implementation
   
   DEPENDENCIES:
   - GSAP 3.12+ (https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/gsap.min.js)
   - ScrollTrigger plugin (https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/ScrollTrigger.min.js)
   
   FRAMER INTEGRATION:
   Option A: Add GSAP via Framer's <head> custom code, then paste this into a Code Override
   Option B: Create a Code Component that imports GSAP and wraps this logic
   Option C: Use Framer's native scroll animations for simpler effects, 
             GSAP for the parallax numeral + staggered service tags
   ═══════════════════════════════════════════════════════════════ */

gsap.registerPlugin(ScrollTrigger);


/* ─── OPENING FRAME ───
   Plays on page load (not scroll-triggered)
   Framer alternative: Use "Appear" animations with staggered delays
   ──────────────────────────────────────────── */
const openingTL = gsap.timeline({ delay: 0.3 });

openingTL
  .to('.opening-logo', { 
    opacity: 1, 
    scale: 1, 
    duration: 1, 
    ease: 'power2.out' 
  })
  .to('.opening-tagline', { 
    opacity: 1, 
    duration: 0.8, 
    ease: 'power2.out' 
  }, '-=0.4')
  .to('.opening-subtitle', { 
    opacity: 1, 
    duration: 0.8, 
    ease: 'power2.out' 
  }, '-=0.3')
  .to('.scroll-indicator', { 
    opacity: 1, 
    duration: 0.6, 
    ease: 'power2.out' 
  }, '-=0.2');


/* ─── OPENING FADE ON SCROLL ───
   As user scrolls past opening, it fades and scales down slightly
   Framer alternative: "While scrolling in view" with opacity + scale
   ──────────────────────────────────────────── */
gsap.to('.opening', {
  opacity: 0,
  scale: 0.95,
  scrollTrigger: {
    trigger: '.opening',
    start: 'top top',
    end: '80% top',
    scrub: 1                // Scrub = animation progress tied to scroll position
  }
});


/* ─── PROGRESS BAR ───
   Thin bar across top, width goes from 0% to 100% as page scrolls
   Framer alternative: Code override on a fixed div, reading scroll position
   ──────────────────────────────────────────── */
gsap.to('#progressBar', {
  width: '100%',
  ease: 'none',
  scrollTrigger: {
    trigger: 'body',
    start: 'top top',
    end: 'bottom bottom',
    scrub: 0.3
  }
});


/* ─── STAGE NAV VISIBILITY ───
   Nav dots appear when first stage enters, disappear after closing
   Framer alternative: Conditional visibility based on scroll position
   ──────────────────────────────────────────── */
ScrollTrigger.create({
  trigger: '#launch',
  start: 'top 80%',
  endTrigger: '#closing',
  end: 'top 50%',
  onEnter: ()     => document.getElementById('stageNav').classList.add('visible'),
  onLeave: ()     => document.getElementById('stageNav').classList.remove('visible'),
  onEnterBack: () => document.getElementById('stageNav').classList.add('visible'),
  onLeaveBack: () => document.getElementById('stageNav').classList.remove('visible'),
});


/* ─── STAGE NAV DOT CLICKS ─── */
document.querySelectorAll('.stage-dot').forEach(dot => {
  dot.addEventListener('click', () => {
    const target = document.getElementById(dot.dataset.target);
    if (target) target.scrollIntoView({ behavior: 'smooth' });
  });
});


/* ─── STAGE SECTION ANIMATIONS ───
   This is the core scroll sequence. Each stage section triggers
   a timeline when it enters the viewport.
   
   ANIMATION SEQUENCE PER STAGE:
   1. Sideways label fades in         (0.6s)
   2. Large numeral fades in           (1.0s, overlapping)
   3. Stage label slides up + fades    (0.5s)
   4. Stage name slides up + fades     (0.7s)
   5. Focus text slides up + fades     (0.6s)
   6. Service tags stagger in          (0.4s each, 0.08s stagger)
   7. Proof point slides up + fades    (0.6s)
   
   Total perceived duration: ~2.5s from first element to last
   
   Framer alternative: 
   - Steps 1-5 can use Framer's "Scroll Animation" with staggered delays
   - Step 6 (staggered tags) is where GSAP really shines — Framer can 
     approximate with manually delayed scroll animations per tag, or use 
     a Code Override for the stagger
   ──────────────────────────────────────────── */

document.querySelectorAll('.stage-section').forEach((section, i) => {
  const stage = section.dataset.stage;
  const tags = section.querySelectorAll('.service-tag');
  const dot = document.querySelectorAll('.stage-dot')[i];

  const tl = gsap.timeline({
    scrollTrigger: {
      trigger: section,
      start: 'top 65%',           // Animation starts when top of section hits 65% of viewport
      end: 'bottom 30%',
      toggleActions: 'play none none reverse',  // Play forward on enter, reverse on leave back
      
      // Active dot tracking
      onEnter: () => {
        document.querySelectorAll('.stage-dot').forEach(d => d.classList.remove('active'));
        if (dot) dot.classList.add('active');
      },
      onEnterBack: () => {
        document.querySelectorAll('.stage-dot').forEach(d => d.classList.remove('active'));
        if (dot) dot.classList.add('active');
      }
    }
  });

  // 1. Sideways label
  tl.to(section.querySelector('.stage-sideways'), {
    opacity: 1, duration: 0.6, ease: 'power2.out'
  });
  
  // 2. Large numeral
  tl.to(section.querySelector('.stage-numeral'), {
    opacity: 1, duration: 1, ease: 'power2.out'
  }, '-=0.4');
  
  // 3. Stage label (e.g., "stage 01")
  tl.to(section.querySelector('.stage-label'), {
    opacity: 1, y: 0, duration: 0.5, ease: 'power2.out'
  }, '-=0.6');
  
  // 4. Stage name (e.g., "launch")
  tl.to(section.querySelector('.stage-name'), {
    opacity: 1, y: 0, duration: 0.7, ease: 'power2.out'
  }, '-=0.3');
  
  // 5. Focus descriptor
  tl.to(section.querySelector('.stage-focus'), {
    opacity: 1, y: 0, duration: 0.6, ease: 'power2.out'
  }, '-=0.3');

  // 6. Service tags — staggered cascade
  tl.to(tags, {
    opacity: 1, y: 0, duration: 0.4, stagger: 0.08, ease: 'power2.out'
  }, '-=0.2');

  // 7. Proof point
  tl.to(section.querySelector('.proof-point'), {
    opacity: 1, y: 0, duration: 0.6, ease: 'power2.out'
  }, '-=0.1');

  
  /* ─── NUMERAL PARALLAX ───
     The big outlined number drifts upward as you scroll through the section.
     This is a scrubbed animation (tied to scroll position, not time).
     
     Framer alternative: "While scrolling in view" trigger on the numeral,
     with a Y-axis move of -60px
     ──────────────────────────────────────────── */
  gsap.to(section.querySelector('.stage-numeral'), {
    y: -60,
    ease: 'none',
    scrollTrigger: {
      trigger: section,
      start: 'top bottom',
      end: 'bottom top',
      scrub: 1
    }
  });
});


/* ─── CLOSING FRAME ───
   Stage words resolve together, then wordmark, tagline, CTA
   
   Framer alternative: "Scroll into view" with staggered delays
   ──────────────────────────────────────────── */
const closingTL = gsap.timeline({
  scrollTrigger: {
    trigger: '.closing',
    start: 'top 60%',
    toggleActions: 'play none none reverse'
  }
});

closingTL
  .to('.closing-stage-word', {
    opacity: 1, y: 0, duration: 0.5, stagger: 0.15, ease: 'power2.out'
  })
  .to('.closing-wordmark', {
    opacity: 1, scale: 1, duration: 0.8, ease: 'power2.out'
  }, '-=0.2')
  .to('.closing-tagline', {
    opacity: 1, duration: 0.6, ease: 'power2.out'
  }, '-=0.3')
  .to('.closing-cta', {
    opacity: 1, y: 0, duration: 0.5, ease: 'power2.out'
  }, '-=0.2');
